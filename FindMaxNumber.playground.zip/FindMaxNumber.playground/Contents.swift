func findMax(_ numbers: [Int]) -> Int{
    var max = 0
     max = numbers[0]
    for i in numbers {
        if i > max {
            max = i
            
        }

    }
    return max
}

let numbers = [1,22,3,99]


print(findMax(numbers))
