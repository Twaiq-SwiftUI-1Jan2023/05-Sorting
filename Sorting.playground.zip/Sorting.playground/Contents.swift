import UIKit

//Sorting Two Numbers
func sortNumbers(x :Int ,y :Int) -> (Int , Int) {
    return x > y ? (x , y): (x , y)
}
print (sortNumbers(x: 77, y: 19))


//sorting Three Numbers
func sortNumbers2(h: inout Int ,a: inout Int ,s :inout Int) -> (Int , Int , Int)-> Int {
    var num :Int
    if h < a {
        num = h
        h = a
    }
    if h < s {
        num = h
        h = s
        s = num
    }
    if (a < s){
        num = a;
        a = s ;
        s = num ;
    }
        return (h,a ,s)
}
var number1 = 28
var number2 = 15
var number3 = 19
let result = sortNumbers2(h: &number1, a: &number2, s: &number3)
print(result)

//Finding the Maximum Number in an Array
var array = [1,2,3,4,5,6,7,8,9,10]
func findMax (array :Array <Int>)-> Int{
    var max :Int = array[0]
    for numb > max {
        max = numb
    }
    return max
}
print (findMax(array: array))
