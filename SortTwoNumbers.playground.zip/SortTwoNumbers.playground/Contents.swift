import UIKit

func sortNumbers(a: Int, b: Int) -> (Int, Int) {

    return a > b ? (a,b) : (b,a)
}
print(sortNumbers(a:2, b: 10))
print(sortNumbers(a:19, b: 4))
print(sortNumbers(a:-5, b: -4))


func sortNumber(a: Int, b: Int, c: Int) -> (Int, Int, Int) {
    var numbers = [a, b, c]
    for i in 0...2 {
    for x in 0...2 {
        if numbers[x] > numbers[i] {
            let temp = numbers[i]
            numbers[i] = numbers[x]
            numbers[x] = temp
        }
    }
    }
    
    return (numbers[0], numbers[1], numbers[2])
}
print(sortNumber(a: 7, b: 1, c: 55))
print(sortNumber(a: 29, b: 32, c: -2))
print(sortNumber(a: 54, b: 40, c: 6))

func findMax(numbers: [Int]) -> Int {
    var maxNumber = numbers[0]
    for number in numbers {
        if number > maxNumber {
            maxNumber = number
        }
    }
    return maxNumber
}

print(findMax(numbers: [3,50,66,7,9]))
print(findMax(numbers: [36,543,76,541]))
print(findMax(numbers: [9,30,46,11,5,-1,34]))
