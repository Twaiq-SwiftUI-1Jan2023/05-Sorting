import UIKit


//Part 1: Sorting Two Numbers
func sortNumbers(a: Int, b: Int) -> (Int, Int){
    if a < b{
           return (a , b)
       } else{
           return (b, a)
       }
}

let s1 = sortNumbers(a: 5, b: 3)
print(s1)




//Part 2: Sorting Three Numbers
func sortNumbers(a:  inout Int, b: inout Int, c: inout Int) -> (Int, Int, Int){
    if b < a {
      var temp = a
      a = b
      b = temp
    }

    if c < b {
     var temp = b
      b = c
      c = temp
    }

    if b < a {
     var temp = a
      a = b
      b = temp
    }

     return (a,b,c)
   
  }
var num1 = 1 , num2 = 3 , num3 = 0
let s2 = sortNumbers(a: &num1, b: &num2, c: &num3)
print(s2)



//Part 3: Finding the Maximum Number in an Array
func findMax (number : [Int])-> Int{
    var large = 0
    for i in 0...number.count-1 {
        if number[i] > large {
            large = number[i]
        }
    }
     return large
}
let max = findMax(number: [3,6,2,8,0,1])
print(max)



